# Real dashboard adaptation: 500 synthetic images

500 grayscale 512x512 PNGs derived from three locally repaired real dashboard frames. This expands the approved 20-image preview without modifying that preview.

- Training: 400 images, 200 each from source plates 0 and 180.
- Validation: 100 images from source plate 204. No test split.
- This validation is a same-video synthetic source-holdout diagnostic. The plates share calibration and repair donors; results cannot establish accuracy on independent videos.
- Requested indicated speeds span 0-180 km/h with fractional readings and exact20km/h anchors. They are synthetic rendering targets, not road-speed measurements.
- Calibration remains a manual visual estimate. Exact rendering labels do not establish exact physical dial calibration.
- LCD pixels are filled with128 before augmentation and again afterward. Warning lights inside the needle sweep remain visible.
- Appearance profiles: clear, dim, reflection, shadow, blur, motion, compression, bright. Camera variations use +/-3deg roll, .985-1.015scale and +/-1.5px perspective-corner offsets. Framing is exactly75% near-reference (+/-8px translation) and25% wider framing (+/-64px translation), per source plate. Real-frame registration found about50-69px corner displacement even in this nominally fixed-camera recording, motivating this range.
- labels.json includes pivot/tip, tick anchors, masks, rendering homographies, provenance, and an independently image-estimated registration to masked_reference.png. A rejected registration must not be silently replaced by the known rendering homography for evaluation.
- needle_mask is the geometric pre-photometric rendered support, thresholded at alpha>.14. Blur can spread visible appearance beyond that binary support.
- No real labeled training examples or independent real test examples are included.

Inspect qa/contact_inputs.jpg, qa/contact_labels.jpg and qa/checks.json.
