Augmented synthetic ring/needle dataset v2

500 training, 100 validation, 100 test images; 512 x 512 grayscale JPEG95.
350 independent camera/needle/occlusion families, two appearance siblings each.
Split assignment precedes rendering; no sibling family crosses splits.
360-degree camera roll, scale 0.85-1.05, translation up to 24 px, shear up to 6 degrees,
perspective corner jitter 16-28 px; all labelled dial geometry retained in frame.
25% clean/light appearance; 40% of samples have 1-2 controlled tick occlusions.
Opaque patches avoid the needle; labels use geometry before photo blur/noise.
No mirrors. Speed does not change under camera or appearance augmentation.
Three mask PNGs: visible arc, arc valid, and packed provenance bits. See labels.json.
Only visible arc/valid mask and visible tick targets enter loss.
Validation/test are synthetic family holdouts from one reconstructed master,
not independent real-camera accuracy. Inferred 60 km/h calibration remains provisional.
Reproduce from published ring_training_v2/generate_dataset.py and render_source/.
The frozen source assets are separate from this dataset archive.
