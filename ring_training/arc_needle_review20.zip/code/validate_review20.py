"""Independent, read-only audit of the 20 arc/needle review examples.

Run with Python + NumPy, OpenCV and Pillow. Does not import the generator or
geometry reader, render a dataset, train a model, or alter any review file.
Only review20_validation.json (beside this script) is written.
"""
from collections import Counter
from pathlib import Path
import csv
import hashlib
import json
import math
import traceback

import cv2
import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
DATA = HERE / "review20"
REPORT = HERE / "review20_validation.json"
MASKS = {"needle_shaft", "arc_amodal", "arc_visible", "arc_occluded_by_needle",
         "source60_uncertainty", "arc_ignore", "arc_loss_valid", "image_footprint"}
NAMES = {"tick_0", "tick_40", "tick_80", "tick_120", "tick_160", "tick_180"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def require(ok, message):
    if not ok:
        raise AssertionError(message)


def close(actual, expected, tolerance, context):
    a, b = np.asarray(actual, float), np.asarray(expected, float)
    require(a.shape == b.shape and np.isfinite(a).all(), context + ": shape/finite")
    error = float(np.max(np.abs(a - b)))
    require(error <= tolerance, f"{context}: {error} > {tolerance}")
    return error


def project(points, matrix):
    points = np.asarray(points, float).reshape(-1, 2)
    p = np.column_stack([points, np.ones(len(points))])
    q = p @ np.asarray(matrix, float).T
    require(np.min(np.abs(q[:, 2])) > 1e-10, "point at infinity")
    return q[:, :2] / q[:, 2, None]


def camera_from_metadata(camera):
    """Rebuild roll analytically, using the documented pixel-center convention."""
    angle = math.radians(camera["clockwise_rotation_degrees"])
    c, s = math.cos(angle), math.sin(angle)
    linear = float(camera["scale"]) * np.array([[c, -s], [s, c]])
    rotation = np.eye(3)
    rotation[:2, :2] = linear
    centre = np.array([255.5, 255.5])
    rotation[:2, 2] = centre - linear @ centre + camera["translation_px"]
    corners = np.array([[0, 0], [511, 0], [511, 511], [0, 511]], np.float32)
    perspective = cv2.getPerspectiveTransform(
        corners, corners + np.asarray(camera["perspective_corner_offsets_px"], np.float32))
    ratio = 511 / 1221
    crop_resize = np.array([[ratio, 0, -16 * ratio], [0, ratio, -16 * ratio], [0, 0, 1]])
    return perspective @ rotation @ crop_resize


def warp_mask(mask, matrix):
    uncrop = np.array([[1, 0, 16], [0, 1, 16], [0, 0, 1]], float)
    return cv2.warpPerspective(mask[16:-16, 16:-16], matrix @ uncrop, (512, 512),
                               flags=cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT)


def independent_speed(row, source_ticks, speeds, angles):
    """Fit output-to-source geometry from visible ticks; never read oracle H."""
    visible = [t for t in row["tick_landmarks"] if t["visible"]]
    observed = np.asarray([t["xy"] for t in visible], np.float64)
    template = np.asarray([source_ticks[t["name"]] for t in visible], np.float64)
    inverse, _ = cv2.findHomography(observed, template, method=0)
    require(inverse is not None, "independent homography unavailable")
    p, t = project([row["needle_position_px"]["pivot"],
                    row["needle_position_px"]["tip"]], inverse)
    delta = t - p
    angle = math.atan2(delta[1], delta[0])
    angle += round((float(np.mean(angles)) - angle) / (2 * math.pi)) * 2 * math.pi
    # Tiny endpoint numerical excursions are accepted, not arbitrary clipping.
    require(angles[0] - 1e-5 <= angle <= angles[-1] + 1e-5, "needle outside calibrated arc")
    value = float(np.interp(angle, angles, speeds))
    residual = float(np.max(np.linalg.norm(project(observed, inverse) - template, axis=1)))
    return value, residual


def audit():
    labels = read(DATA / "labels.json")
    rows = labels["samples"]
    require(labels["schema_version"] == "arc_needle_review20_v1", "schema")
    require(labels["count"] == len(rows) == 20 and labels["resolution"] == [512, 512], "count/resolution")
    require(len({r["sample_id"] for r in rows}) == 20, "sample IDs unique")
    source_hashes = labels["source_artifact_hashes"]
    require(len(source_hashes) == 10, "frozen source inventory")
    for name, expected in source_hashes.items():
        require(sha(PROJECT / name) == expected, "source hash: " + name)
    annotation_path = PROJECT / "ring_annotation_review/source_annotations.json"
    calibration_path = PROJECT / "bw_dataset_500/calibration.json"
    annotation, calibration = read(annotation_path), read(calibration_path)
    require(sha(DATA / "source_annotations_snapshot.json") == sha(annotation_path), "annotation snapshot")
    require(sha(DATA / "calibration_snapshot.json") == sha(calibration_path), "calibration snapshot")
    require(labels["source_annotations_sha256"] == sha(annotation_path), "annotation provenance")
    require(labels["source_master_sha256"] == annotation["source"]["sha256"]
            == calibration["source_sha256"], "master provenance")

    preparation_path = PROJECT / "bw_dataset_500/source/preparation.json"
    preparation = read(preparation_path)
    pivot = np.asarray(calibration["pivot_xy"], float)
    close(preparation["pivot_xy"], pivot, 0, "preparation pivot")
    ticks = sorted(calibration["ticks"], key=lambda t: t["speed_kmh"])
    speeds = np.asarray([t["speed_kmh"] for t in ticks], float)
    vectors = np.asarray([t["inner_tick_xy"] for t in ticks]) - pivot
    angles = np.unwrap(np.arctan2(vectors[:, 1], vectors[:, 0]))
    radii = np.linalg.norm(vectors, axis=1)
    require(np.all(np.diff(angles) > 0), "calibration angle order")
    source_ticks = {t["name"]: np.asarray(t["xy_source"], float)
                    for t in annotation["named_tick_landmarks"]}
    require(set(source_ticks) == NAMES, "six source anchors")
    source_arc = cv2.imread(str(annotation_path.parent / "masks/arc_amodal_inferred.png"), 0)
    source_ignore = cv2.imread(str(annotation_path.parent / "masks/arc_ignore.png"), 0)
    cap = cv2.imread(str(PROJECT / "bw_dataset_500/source/cap_mask.png"), 0)
    with np.load(PROJECT / "bw_dataset_500/source/needle_layer.npz") as layer:
        original_alpha = layer["alpha"].copy()
    source_tip = np.asarray(preparation["source_needle_tip_xy"], float)
    results, groups, referenced_files = [], {}, set()
    for row in rows:
        ident = row["sample_id"]
        require(row["dataset_split"] == "review_only", ident + ": review split")
        require(row["review_status"] == "pending_user_inspection", ident + ": user review pending")
        require(row["speed_label_type"] == "intended_synthetic_speed", ident + ": label type")
        require((row["width"], row["height"], row["channels"]) == (512, 512, 1), ident + ": dimensions")
        require(sha(DATA / row["image"]) == row["image_sha256"], ident + ": image hash")
        with Image.open(DATA / row["image"]) as im:
            require(im.mode == "L" and im.size == (512, 512), ident + ": grayscale image")
        referenced_files.add(row["image"])
        require(set(row["masks"]) == MASKS == set(row["mask_sha256"]), ident + ": mask inventory")
        masks = {}
        for name, path in row["masks"].items():
            require(sha(DATA / path) == row["mask_sha256"][name], ident + ": " + name + " hash")
            with Image.open(DATA / path) as im:
                require(im.mode == "L" and im.size == (512, 512), ident + ": mask dimensions")
                masks[name] = np.asarray(im).copy()
            require(set(np.unique(masks[name])).issubset({0, 255}), ident + ": nonbinary mask")
            referenced_files.add(path)

        speed = float(row["speed_kmh"])
        angle, radius = np.interp(speed, speeds, angles), np.interp(speed, speeds, radii)
        anchor = pivot + radius * np.array([math.cos(angle), math.sin(angle)])
        tip = pivot + (anchor - pivot) * preparation["needle_to_inner_tick_radius_ratio"]
        close(row["source_pivot_xy"], pivot, 1e-8, ident + ": source pivot")
        close(row["source_tick_anchor_xy"], anchor, 1e-8, ident + ": source tick anchor")
        close(row["source_target_tip_xy"], tip, 1e-8, ident + ": source tip")
        u, v = source_tip - pivot, tip - pivot
        complex_ratio = complex(*v) / complex(*u)
        a, b = complex_ratio.real, complex_ratio.imag
        linear = np.array([[a, -b], [b, a]])
        needle_transform = np.eye(3)
        needle_transform[:2, :2] = linear
        needle_transform[:2, 2] = pivot - linear @ pivot
        close(row["needle_transform_source_3x3"], needle_transform, 1e-9, ident + ": needle transform")
        matrix = np.asarray(row["source_to_output_homography_3x3"])
        camera_error = close(matrix, camera_from_metadata(row["camera"]), 1e-9, ident + ": camera transform")
        transform_errors = []
        for name, source in [("pivot", pivot), ("tip", tip), ("tick_anchor", anchor)]:
            xy = row["needle_position_px"][name]
            transform_errors.append(close(xy, project([source], matrix)[0], 1e-7, ident + ": " + name))
            close(row["needle_position_normalized"][name], np.asarray(xy) / 511, 1e-12, ident + ": normalized " + name)
        arc_error = close(row["arc_centerline_px"], project(annotation["scale_arc"]["centerline_xy"], matrix),
                          5.1e-7, ident + ": arc transform")
        source_alpha = cv2.warpAffine(original_alpha, np.asarray(row["needle_transform_source_3x3"])[:2],
                                     (1254, 1254), flags=cv2.INTER_LINEAR)
        source_alpha[cap > 0] = 0
        expected_shaft = (source_alpha > .35).astype(np.uint8) * 255
        expected_base = {"needle_shaft": warp_mask(expected_shaft, matrix),
                         "arc_amodal": warp_mask(source_arc, matrix),
                         "source60_uncertainty": warp_mask(source_ignore, matrix),
                         "image_footprint": warp_mask(np.full(source_arc.shape, 255, np.uint8), matrix)}
        for name, expected in expected_base.items():
            require(np.array_equal(masks[name], expected), ident + ": source-derived " + name)
        dilated = cv2.dilate(masks["needle_shaft"], np.ones((3, 3), np.uint8)) > 0
        arc, static = masks["arc_amodal"] > 0, masks["source60_uncertainty"] > 0
        occluded = arc & dilated
        ignore = static | occluded
        expected_derived = {"arc_occluded_by_needle": occluded, "arc_ignore": ignore,
                            "arc_visible": arc & ~ignore,
                            "arc_loss_valid": (masks["image_footprint"] > 0) & ~ignore}
        for name, expected in expected_derived.items():
            require(np.array_equal(masks[name] > 0, expected), ident + ": boolean mask rule " + name)
        require(np.count_nonzero(static) > 0 and np.count_nonzero(occluded) > 0,
                ident + ": static and dynamic ignore must exist")
        landmarks = row["tick_landmarks"]
        require({t["name"] for t in landmarks} == NAMES and len(landmarks) == 6, ident + ": anchor names")
        for tick in landmarks:
            xy = np.asarray(tick["xy"])
            transform_errors.append(close(xy, project([source_ticks[tick["name"]]], matrix)[0],
                                          1e-7, ident + ": tick transform"))
            close(tick["xy_normalized"], xy / 511, 1e-12, ident + ": normalized tick")
            x, y = np.rint(xy).astype(int)
            visible = not (dilated[y, x] or static[y, x])
            require(tick["visible"] == tick["heatmap_loss_valid"] == visible, ident + ": tick visibility")
            require(tick["speed_kmh"] == int(tick["name"].split("_")[1]), ident + ": tick speed")
        visible_count = sum(t["visible"] for t in landmarks)
        require(visible_count == row["visible_tick_count"] and visible_count >= 4, ident + ": visible anchors")
        all_points = np.vstack([list(row["needle_position_px"].values()),
                                [t["xy"] for t in landmarks], row["arc_centerline_px"]])
        require(np.all((all_points >= 4) & (all_points <= 507)), ident + ": labelled geometry not clipped")
        inferred = any(t["method"] != "manual_visible_tick" for t in ticks
                       if t["speed_kmh"] in {10 * math.floor(speed / 10), 10 * math.ceil(speed / 10)})
        require(bool(row["inferred_60_influence"]) == inferred, ident + ": inferred60 flag")
        reading, residual = independent_speed(row, source_ticks, speeds, angles)
        error = abs(reading - speed)
        require(error < .002, ident + ": independent speed")
        require(row["geometry_reading"]["accepted"], ident + ": stored geometry rejected")
        close(row["geometry_reading"]["speed_kmh"], reading, .002, ident + ": stored reading")
        close(row["geometry_absolute_error_kmh"], abs(row["geometry_reading"]["speed_kmh"] - speed),
              1e-12, ident + ": stored error")
        group = row["source_pose_group"]
        require(group not in groups or groups[group] == speed, ident + ": inconsistent pose group")
        groups[group] = speed
        results.append({"sample_id": ident, "speed_kmh": speed, "visible_anchors": visible_count,
                        "independent_speed_kmh": reading, "independent_error_kmh": error,
                        "independent_anchor_fit_max_error_source_px": residual,
                        "max_point_transform_error_px": max(transform_errors), "arc_transform_error_px": arc_error,
                        "camera_matrix_max_error": camera_error,
                        "static_ignore_pixels": int(np.count_nonzero(static)),
                        "dynamic_arc_occlusion_pixels": int(np.count_nonzero(occluded))})
    require(len(groups) == 18, "18 source pose groups")
    sixties = [r for r in rows if r["speed_kmh"] == 60]
    require(len(sixties) == 3 and len({r["source_pose_group"] for r in sixties}) == 1, "matched 60 group")
    require(len({r["image_sha256"] for r in rows}) == 20, "unique input images")
    actual = {p.relative_to(DATA).as_posix() for folder in [DATA / "images", DATA / "masks"]
              for p in folder.rglob("*.png")}
    require(actual == referenced_files and len(actual) == 180, "20 inputs and 160 masks, no orphan PNGs")
    with (DATA / "labels.csv").open(newline="", encoding="utf-8") as f:
        csv_rows = list(csv.DictReader(f))
    require(len(csv_rows) == 20, "CSV count")
    for c, row in zip(csv_rows, rows):
        require(c["sample_id"] == row["sample_id"] and c["image"] == row["image"]
                and c["source_pose_group"] == row["source_pose_group"]
                and c["dataset_split"] == "review_only", "CSV identity")
        close(float(c["speed_kmh"]), row["speed_kmh"], 0, "CSV speed")
        close([float(c[n]) for n in ["pivot_x", "pivot_y", "tip_x", "tip_y"]],
              row["needle_position_px"]["pivot"] + row["needle_position_px"]["tip"], 1e-10, "CSV needle")
    visual_files = ["contact_sheet_inputs.png", "contact_sheet_labels.png", "same_speed_three_views.png"]
    return {
        "passed": True, "scope": "Independent review-only source/labels/masks/geometry audit; no training",
        "labels_sha256": sha(DATA / "labels.json"), "image_count": 20, "binary_mask_count": 160,
        "source_artifact_hashes_verified": source_hashes,
        "additional_dependency_hashes": {"bw_dataset_500/source/preparation.json": sha(preparation_path)},
        "source_pose_groups": len(groups), "all_splits": ["review_only"],
        "minimum_visible_named_anchors": min(r["visible_anchors"] for r in results),
        "visible_anchor_counts": dict(Counter(r["visible_anchors"] for r in results)),
        "max_independent_speed_error_kmh": max(r["independent_error_kmh"] for r in results),
        "max_point_transform_error_px": max(r["max_point_transform_error_px"] for r in results),
        "max_arc_rounding_error_px": max(r["arc_transform_error_px"] for r in results),
        "source_warp_mask_mismatched_pixels": 0, "boolean_mask_rule_mismatched_pixels": 0,
        "speed_audit_method": "OpenCV non-RANSAC output-to-source homography from visible named anchors only; rectify needle; interpolate frozen 19-tick calibration. Generator and geometry_reader are not imported; stored oracle H is not used for speed recovery.",
        "visual_review": {"performed_by": "Independent audit agent", "files": {f: sha(DATA / f) for f in visual_files},
                          "assessment": "Viewed both full contact sheets and matched 60 km/h trio. Arc overlays follow the printed scale, needle labels follow the rendered shaft, and camera rotation preserves speed. No visible duplicate needle or stray white dot. Synthetic gray border corners and mild image noise/blur remain visible as expected."},
        "limitations": ["Checks establish internal synthetic geometry consistency, not physical speed accuracy or model accuracy.",
                        "The approved ImageGen reconstruction and inferred 60 km/h calibration remain physically unverified.",
                        "Masks and landmark visibility describe pre-photometric geometry; blur/reflection may reduce practical visibility.",
                        "All samples are correlated review variants, pending user inspection, without a training/test split.",
                        "Needle source/preparation.json is additionally hashed here; it is not present in the generator source_artifact_hashes inventory."],
        "samples": results,
    }


if __name__ == "__main__":
    try:
        result = audit()
    except Exception as exc:
        result = {"passed": False, "error": str(exc), "traceback": traceback.format_exc()}
    REPORT.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k not in {"samples", "source_artifact_hashes_verified"}}, indent=2))
    raise SystemExit(0 if result["passed"] else 1)
