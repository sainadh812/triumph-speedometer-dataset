"""Render the Step3 review set from frozen approved layers. No training or imagegen.

Run from this project with the existing speedometer Python environment. Review
overlays are separate from the 20 single-channel model input PNGs.
"""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import math
import shutil
import sys

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
OUT = ROOT / 'review20'
ANNOTATIONS = PROJECT / 'ring_annotation_review/source_annotations.json'
SEED = 202610170203
SIZE = 512
ANCHORS = ['tick_0','tick_40','tick_80','tick_120','tick_160','tick_180']
PLAN = [
    (0,0,'clean',0), (20,90,'clean',0), (40,-90,'clean',0),
    (60,0,'clean',0), (60,180,'clean',0), (60,137.4,'mixed',18),
    (80,37.6,'dim_noise',14), (100,-58.3,'shadow',14),
    (120,108.7,'soft_focus',18), (140,-126.4,'reflection',18),
    (160,164.8,'motion',12), (180,-21.5,'clean',20),
    (12.5,73.2,'dim',16), (32.5,-169.6,'noise',18),
    (52.5,24.9,'shadow_noise',16), (67.5,-101.1,'bright_soft',20),
    (92.5,149.2,'compression',18), (112.5,-43.7,'reflection_noise',20),
    (147.5,6.8,'motion_noise',28), (172.5,-74.6,'mixed',24),
]
CYAN=(40,217,232); YELLOW=(255,224,102); PINK=(255,101,195); ORANGE=(255,152,71)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def save(path, pixels):
    path.parent.mkdir(parents=True,exist_ok=True)
    assert cv2.imwrite(str(path),pixels),path


def points_transform(points,H):
    p=np.asarray(points,float).reshape(-1,2)
    q=np.c_[p,np.ones(len(p))]@H.T
    assert np.all(np.abs(q[:,2])>1e-8)
    return q[:,:2]/q[:,2,None]


def load_frozen_renderer():
    folder=PROJECT/'bw_dataset_500'
    sys.path.insert(0,str(folder))
    spec=importlib.util.spec_from_file_location('approved_bw_renderer',folder/'generate.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.DatasetRenderer(folder),module.photo_effects


def warp(pixels,H,nearest=False,border=0):
    # H refers to full-source coordinates; match the established16px source crop.
    shift=np.array([[1,0,16],[0,1,16],[0,0,1]],float)
    return cv2.warpPerspective(pixels[16:-16,16:-16],H@shift,(SIZE,SIZE),
                              flags=cv2.INTER_NEAREST if nearest else cv2.INTER_LINEAR,
                              borderMode=cv2.BORDER_CONSTANT,borderValue=border)


def camera(rng,clockwise,jitter):
    scale=511/1221
    B=np.array([[scale,0,-16*scale],[0,scale,-16*scale],[0,0,1]],float)
    R=np.eye(3)
    magnification=float(rng.uniform(.94,1.02)) if jitter else 1.0
    R[:2]=cv2.getRotationMatrix2D((255.5,255.5),-clockwise,magnification)
    translation=rng.uniform(-6,6,2) if jitter else np.zeros(2)
    R[:2,2]+=translation
    corners=np.array([[0,0],[511,0],[511,511],[0,511]],np.float32)
    offsets=rng.uniform(-jitter,jitter,(4,2)).astype('float32') if jitter else np.zeros((4,2),'float32')
    P=cv2.getPerspectiveTransform(corners,corners+offsets)
    H=P@R@B
    return H,dict(clockwise_rotation_degrees=clockwise,scale=magnification,
                  translation_px=translation.tolist(),perspective_corner_offsets_px=offsets.tolist(),
                  perspective_corner_max_jitter_px=jitter,source_crop_xywh=[16,16,1222,1222],
                  border_mode='constant',rotation_means_camera_roll_not_needle_speed=True)


def font(size,bold=False):
    for name in ['DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf',
                 'C:/Windows/Fonts/arialbd.ttf' if bold else 'C:/Windows/Fonts/arial.ttf']:
        try:return ImageFont.truetype(name,size)
        except OSError:pass
    return ImageFont.load_default()


def overlay(image,row,arc_visible,ignore):
    canvas=Image.fromarray(image).convert('RGB')
    fill=np.zeros((512,512,4),dtype=np.uint8)
    fill[arc_visible>0]=(*CYAN,70)
    fill[(ignore>0)&(row['_arc_amodal']>0)]=(*ORANGE,120)
    canvas=Image.alpha_composite(canvas.convert('RGBA'),Image.fromarray(fill)).convert('RGB')
    d=ImageDraw.Draw(canvas)
    p=row['needle_position_px']['pivot'];t=row['needle_position_px']['tip']
    d.line([tuple(p),tuple(t)],fill=PINK,width=2)
    for q in [p,t]:
        x,y=q;d.line([(x-4,y),(x+4,y)],fill=PINK,width=2);d.line([(x,y-4),(x,y+4)],fill=PINK,width=2)
    for item in row['tick_landmarks']:
        x,y=item['xy'];color=YELLOW if item['visible'] else ORANGE
        d.ellipse([x-3,y-3,x+3,y+3],outline=color,fill=color if item['visible'] else None,width=2)
        v=np.array([x,y])-np.array(p);v=v/(np.linalg.norm(v)+1e-9)
        tx,ty=np.array([x,y])+v*17
        text=str(item['speed_kmh'])
        d.text((tx,ty),text,font=font(13,True),fill=color,anchor='mm',stroke_width=2,stroke_fill=(10,15,22))
    # The overlay has no title burned into source pixels; contact-sheet captionsare outside.
    return np.asarray(canvas)


def contact_sheet(rows,labels=False):
    tile=256;gap=14;footer=62;header=90;cols=4
    sheet=Image.new('RGB',(cols*tile+(cols+1)*gap,header+5*(tile+footer+gap)+gap),(14,23,38))
    d=ImageDraw.Draw(sheet)
    d.text((gap,16),'20 REVIEW IMAGES  |  '+('LABEL OVERLAYS' if labels else 'GRAYSCALE INPUTS'),
           font=font(25,True),fill='white')
    d.text((gap,53),'512 x 512 each | rotation, perspective, light and blur | * uses inferred 60 km/h calibration',
           font=font(14),fill=(190,204,222))
    for i,row in enumerate(rows):
        x=gap+(i%cols)*(tile+gap);y=header+(i//cols)*(tile+footer+gap)
        path=OUT/(row['label_overlay'] if labels else row['image'])
        with Image.open(path) as im:sheet.paste(im.convert('RGB').resize((tile,tile),Image.Resampling.LANCZOS),(x,y))
        star=' *' if row['inferred_60_influence'] else ''
        d.text((x,y+tile+7),f"#{row['id']:02d}  {row['speed_kmh']:g} km/h{star} | roll {row['camera']['clockwise_rotation_degrees']:+g}°",
               font=font(15,True),fill='white')
        profile=row['photometric']['profile'].replace('_',' ')
        persp=' + perspective' if row['camera']['perspective_corner_max_jitter_px'] else ''
        d.text((x,y+tile+31),profile+persp,font=font(13),fill=(190,204,222))
    sheet.save(OUT/('contact_sheet_labels.png' if labels else 'contact_sheet_inputs.png'))


def matched_pose_sheet(rows):
    chosen=[r for r in rows if r['speed_kmh']==60]
    tile=420;gap=16;head=90;foot=95
    sheet=Image.new('RGB',(3*tile+4*gap,head+tile+foot),(14,23,38));d=ImageDraw.Draw(sheet)
    d.text((16,15),'ONE NEEDLE POSE, THREE CAMERA VIEWS',font=font(28,True),fill='white')
    d.text((16,55),'Exact-label geometry check. No trained model is used for these speed calculations.',font=font(17),fill=(190,204,222))
    for i,row in enumerate(chosen):
        x=gap+i*(tile+gap)
        with Image.open(OUT/row['label_overlay']) as im:sheet.paste(im.resize((tile,tile),Image.Resampling.LANCZOS),(x,head))
        d.text((x,head+tile+12),f"Camera roll {row['camera']['clockwise_rotation_degrees']:+g}°",font=font(20,True),fill='white')
        d.text((x,head+tile+43),f"Target 60.0 | calculated {row['geometry_reading']['speed_kmh']:.3f} km/h",font=font(17),fill=CYAN)
    d.text((16,head+tile+73),'60 km/h remains a provisional source calibration; this verifies coordinate consistency.',font=font(14),fill=ORANGE)
    sheet.save(OUT/'same_speed_three_views.png')


def main():
    from geometry_reader import load_template, read_speed
    OUT.mkdir(parents=True,exist_ok=True)
    renderer,photo_effects=load_frozen_renderer()
    annotation=json.loads(ANNOTATIONS.read_text(encoding='utf-8'))
    template=load_template()
    assert annotation['source']['sha256']==sha(PROJECT/'generated_bw_dataset/source/approved_imagegen_master.png')
    source_named={r['name']:np.array(r['xy_source'],float) for r in annotation['named_tick_landmarks']}
    source_arc=cv2.imread(str(ANNOTATIONS.parent/'masks/arc_amodal_inferred.png'),0)
    source_uncertain=cv2.imread(str(ANNOTATIONS.parent/'masks/arc_ignore.png'),0)
    assert source_arc.shape==source_uncertain.shape==renderer.plate.shape
    centreline=np.array(annotation['scale_arc']['centerline_xy'])
    source_ones=np.full(renderer.plate.shape,255,np.uint8)
    inputs=[ANNOTATIONS,ANNOTATIONS.parent/'masks/arc_amodal_inferred.png',ANNOTATIONS.parent/'masks/arc_ignore.png',
            PROJECT/'bw_dataset_500/calibration.json',PROJECT/'bw_dataset_500/generate.py',PROJECT/'bw_dataset_500/render_core.py']
    inputs.extend(PROJECT/'bw_dataset_500/source'/name for name in ['approved_imagegen_master.png','clean_plate.png','cap_mask.png','needle_layer.npz'])
    input_hashes={p.relative_to(PROJECT).as_posix():sha(p) for p in inputs}
    rows=[]
    for ident,(speed,roll,profile,jitter) in enumerate(PLAN,1):
        seed=SEED+ident*7919;rng=np.random.default_rng(seed)
        composite,shaft,tip,anchor,N,method,uncertainty,interpolation=renderer.source_composite(speed)
        H,camera_info=camera(rng,roll,jitter)
        edge=np.r_[composite[16,16:-16],composite[-17,16:-16],composite[16:-16,16],composite[16:-16,-17]]
        border=int(np.median(edge));camera_info['border_gray_value']=border
        framed=warp(composite,H,border=border)
        image,photo=photo_effects(framed,rng,profile)
        needle=warp(shaft,H,nearest=True)
        arc=warp(source_arc,H,nearest=True)
        static_ignore=warp(source_uncertain,H,nearest=True)
        footprint=warp(source_ones,H,nearest=True)
        needle_dilated=cv2.dilate(needle,np.ones((3,3),np.uint8))
        # Segmentation labels describe geometry before light/blur; ignore uncertainandoccludedparts.
        occluded=cv2.bitwise_and(arc,needle_dilated)
        ignore=cv2.bitwise_or(static_ignore,occluded)
        visible=arc.copy();visible[ignore>0]=0
        valid=footprint.copy();valid[ignore>0]=0
        p,t,a=points_transform([renderer.pivot,tip,anchor],H)
        transformed_arc=points_transform(centreline,H)
        transformed_ticks={name:points_transform([point],H)[0] for name,point in source_named.items()}
        all_points=np.r_[p[None],t[None],a[None],transformed_arc,np.array(list(transformed_ticks.values()))]
        assert np.all((all_points>=4)&(all_points<=507)),(ident,'cropped labelled geometry')
        landmarks=[]
        for name,point in transformed_ticks.items():
            x,y=np.rint(point).astype(int)
            covered=bool(needle_dilated[y,x]>0 or static_ignore[y,x]>0)
            landmarks.append(dict(name=name,speed_kmh=int(name.split('_')[1]),xy=point.tolist(),
                                  xy_normalized=(point/511).tolist(),visible=not covered,
                                  visibility_reason='rendered_needle_occlusion' if covered else 'visible_geometrically',
                                  heatmap_loss_valid=not covered))
        usable={k['name']:k['xy'] for k in landmarks if k['visible']}
        assert len(usable)>=4
        reading=read_speed(usable,p.tolist(),t.tolist(),template)
        assert reading['accepted'],(ident,reading)
        error=abs(reading['speed_kmh']-speed)
        assert error<0.002,(ident,error)
        stem=f'review_{ident:02d}'
        mask_arrays={'needle_shaft':needle,'arc_amodal':arc,'arc_visible':visible,
                     'arc_occluded_by_needle':occluded,'source60_uncertainty':static_ignore,
                     'arc_ignore':ignore,'arc_loss_valid':valid,'image_footprint':footprint}
        mask_files={key:f'masks/{key}/{stem}.png' for key in mask_arrays}
        for key,pixels in mask_arrays.items():save(OUT/mask_files[key],pixels)
        image_path=f'images/{stem}.png';save(OUT/image_path,image)
        row=dict(id=ident,sample_id=stem,image=image_path,image_sha256=sha(OUT/image_path),
                 width=512,height=512,channels=1,speed_kmh=speed,speed_label_type='intended_synthetic_speed',
                 source_pose_group=f"source_c1d0e8a1_speed_{speed:06.1f}",dataset_split='review_only',
                 review_status='pending_user_inspection',rng_seed=seed,
                 needle_position_px=dict(pivot=p.tolist(),tip=t.tolist(),tick_anchor=a.tolist()),
                 needle_position_normalized=dict(pivot=(p/511).tolist(),tip=(t/511).tolist(),tick_anchor=(a/511).tolist()),
                 needle_image_angle_degrees=float(np.degrees(np.arctan2(*(t-p)[::-1]))%360),
                 tick_landmarks=landmarks,visible_tick_count=len(usable),
                 arc_centerline_px=transformed_arc.round(6).tolist(),
                 masks=mask_files,mask_sha256={k:sha(OUT/v) for k,v in mask_files.items()},
                 source_to_output_homography_3x3=H.tolist(),needle_transform_source_3x3=N.tolist(),
                 source_pivot_xy=renderer.pivot.tolist(),source_target_tip_xy=tip.tolist(),source_tick_anchor_xy=anchor.tolist(),
                 anchor_method=method,interpolation=interpolation,inferred_60_influence=interpolation['inferred_60_influence'],
                 camera=camera_info,photometric=photo,geometry_reading=reading,geometry_absolute_error_kmh=error,
                 geometry_reading_inputs='visible named tick coordinates and needle pivot/tip only; oracle H withheld',
                 label_overlay=f'overlays/{stem}.png')
        row['_arc_amodal']=arc
        over=overlay(image,row,visible,ignore)
        del row['_arc_amodal']
        (OUT/'overlays').mkdir(exist_ok=True)
        Image.fromarray(over).save(OUT/row['label_overlay'])
        rows.append(row)
    assert all(sha(PROJECT/p)==s for p,s in input_hashes.items()),'Frozen sources modified'
    doc=dict(schema_version='arc_needle_review20_v1',purpose='Steps 2 and 3 review only; not model training or an accuracy test',
             count=20,resolution=[512,512],coordinate_convention='x right, y down, zero-based pixel centres; normalized by 511',
             source_artifact_hashes=input_hashes,source_annotations_sha256=sha(ANNOTATIONS),
             source_master_sha256=annotation['source']['sha256'],master_seed=SEED,
             mask_semantics={'arc_amodal':'Complete fitted ribbon; includes inferred/hidden shape; not observed pixel ground truth',
                             'arc_visible':'Ribbon excluding static 60 km/h uncertainty and new needle occlusion; geometry before photometric effects',
                             'arc_loss_valid':'In-frame pixels outside uncertain/occluded areas; use with arc_visible supervision',
                             'needle_shaft':'Rendered shaft support before blur; stationary hub excluded',
                             'source60_uncertainty':'Fixed uncertainty from reconstructed source 60 km/h region, transformed with camera',
                             'arc_occluded_by_needle':'Complete arc intersected with one-pixel-dilated current needle mask',
                             'arc_ignore':'Union of source60_uncertainty and arc_occluded_by_needle',
                             'image_footprint':'Pixels covered by the transformed source image; excludes synthetic border fill'},
             limitations=['Exact-label geometry results are not learned-model accuracy.',
                          'AI-reconstructed source and inferred 60 km/h calibration remain physically unverified.',
                          'All 20 are correlated review variants; no train/validation/test allocation.',
                          'Constant gray corners are synthetic border fill; check real camera generalization later.'],samples=rows)
    dump(OUT/'labels.json',doc)
    with (OUT/'labels.csv').open('w',newline='',encoding='utf-8') as f:
        fields=['sample_id','image','speed_kmh','camera_roll_degrees','photometric_profile','perspective_jitter_px',
                'pivot_x','pivot_y','tip_x','tip_y','visible_tick_count','calculated_speed_kmh',
                'geometry_error_kmh','inferred_60_influence','source_pose_group','dataset_split']
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for r in rows:
            writer.writerow(dict(zip(fields,[r['sample_id'],r['image'],r['speed_kmh'],r['camera']['clockwise_rotation_degrees'],
                r['photometric']['profile'],r['camera']['perspective_corner_max_jitter_px'],*r['needle_position_px']['pivot'],
                *r['needle_position_px']['tip'],r['visible_tick_count'],r['geometry_reading']['speed_kmh'],
                r['geometry_absolute_error_kmh'],r['inferred_60_influence'],r['source_pose_group'],r['dataset_split']])))
    contact_sheet(rows);contact_sheet(rows,labels=True);matched_pose_sheet(rows)
    shutil.copyfile(ANNOTATIONS,OUT/'source_annotations_snapshot.json')
    shutil.copyfile(PROJECT/'generated_bw_dataset/calibration.json',OUT/'calibration_snapshot.json')
    summary=dict(count=20,resolution=[512,512],source_pose_groups=len({r['source_pose_group'] for r in rows}),
                 source_unchanged=True,training_started=False,all_review_only=True,
                 geometry_accepted_count=sum(r['geometry_reading']['accepted'] for r in rows),
                 geometry_max_absolute_error_kmh=max(r['geometry_absolute_error_kmh'] for r in rows),
                 minimum_visible_named_ticks=min(r['visible_tick_count'] for r in rows),
                 rotation_degrees=[r['camera']['clockwise_rotation_degrees'] for r in rows],
                 photometric_profiles=sorted({r['photometric']['profile'] for r in rows}),
                 inferred60influence_count=sum(r['inferred_60_influence'] for r in rows),
                 source_master_sha256=annotation['source']['sha256'])
    dump(OUT/'review_summary.json',summary)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
