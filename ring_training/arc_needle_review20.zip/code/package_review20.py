"""Bundle the reviewed artifacts with hashes; no training or publishing."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'arc_needle_review20.zip'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    for name in ('geometry_validation.json', 'review20_validation.json'):
        report = json.loads((ROOT / name).read_text(encoding='utf-8'))
        assert report.get('passed') is True, f'Validation not passed: {name}'
    entries = {}
    for path in sorted((ROOT / 'review20').rglob('*')):
        if path.is_file():
            entries[path.relative_to(ROOT).as_posix()] = path
    entries['README.txt'] = ROOT / 'review20/README.txt'
    for name in ('geometry_validation.json', 'review20_validation.json', 'geometry_noise_sensitivity.png'):
        entries[f'reports/{name}'] = ROOT / name
    for name in ('geometry_reader.py', 'generate_review20.py', 'validate_geometry.py',
                 'validate_review20.py', 'package_review20.py'):
        entries[f'code/{name}'] = ROOT / name
    manifest = {
        'purpose': 'Steps 2 and 3 review artifacts; no trained model',
        'files': {name: {'sha256': digest(path.read_bytes()), 'bytes': path.stat().st_size}
                  for name, path in entries.items()},
    }
    with zipfile.ZipFile(OUT, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in entries.items():
            archive.write(path, name)
        archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(OUT) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert all(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts for name in names)
        for name, item in manifest['files'].items():
            assert digest(archive.read(name)) == item['sha256'], name
    summary = {'file': OUT.name, 'bytes': OUT.stat().st_size, 'sha256': digest(OUT.read_bytes()),
               'entry_count': len(names), 'crc_and_manifest_verified': True}
    (ROOT / 'bundle_summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
