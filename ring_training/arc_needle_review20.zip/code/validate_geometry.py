"""Independent geometry checks; no detector, images, training, or accuracy claim.

Expected readings come from the 19 calibration rays. Observed landmarks are
forward-projected independently; the reader never receives the generating H.
"""
from __future__ import annotations

from collections import Counter
from itertools import combinations
from pathlib import Path
import hashlib
import json
import math
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
ANNOTATIONS = PROJECT / "ring_annotation_review" / "source_annotations.json"
CALIBRATION = PROJECT / "generated_bw_dataset" / "calibration.json"
REPORT = ROOT / "geometry_validation.json"
SEED = 20261017


def file_sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def project(points, matrix):
    """Forward projection, independently implemented in the validation file."""
    points = np.asarray(points, dtype=np.float64)
    homogeneous = np.column_stack((points, np.ones(len(points))))
    mapped = homogeneous @ np.asarray(matrix, dtype=np.float64).T
    if np.any(np.abs(mapped[:, 2]) < 1e-12):
        raise ValueError("Test fixture point lies on the projective horizon")
    return mapped[:, :2] / mapped[:, 2, None]


def source_geometry():
    annotation = json.loads(ANNOTATIONS.read_text(encoding="utf-8"))
    calibration = json.loads(CALIBRATION.read_text(encoding="utf-8"))
    pivot = np.array(calibration["pivot_xy"], dtype=float)
    anchors = {r["name"]: np.array(r["xy_source"], dtype=float)
               for r in annotation["named_tick_landmarks"]}
    assert np.allclose(pivot, annotation["needle"]["pivot"]["xy_source"])
    knots = sorted(calibration["ticks"], key=lambda row: row["speed_kmh"])
    speeds = np.array([row["speed_kmh"] for row in knots], dtype=float)
    xy = np.array([row["inner_tick_xy"] for row in knots], dtype=float)
    # atan2 is independently unwrapped by walking increasing speed labels.
    angles = []
    for x, y in xy - pivot:
        angle = math.degrees(math.atan2(y, x))
        while angles and angle <= angles[-1]:
            angle += 360.0
        angles.append(angle)
    angles = np.array(angles)
    assert len(speeds) == 19 and list(speeds) == list(range(0, 181, 10))
    assert 0 < angles[-1] - angles[0] < 360
    return pivot, anchors, speeds, angles


def source_needle(speed, pivot, speeds, angles):
    """Construct a known-speed ray without calling the reader's angle helpers."""
    i = min(max(int(np.searchsorted(speeds, speed, side="right")) - 1, 0), len(speeds) - 2)
    fraction = (float(speed) - speeds[i]) / (speeds[i + 1] - speeds[i])
    angle = angles[i] + fraction * (angles[i + 1] - angles[i])
    rad = math.radians(float(angle))
    return pivot + 300.0 * np.array([math.cos(rad), math.sin(rad)])


def camera_matrix(roll, pivot, family=0, rng=None):
    """Proper rotation, anisotropic/shear projection, and finite perspective.

    Matrices map source coordinates into a nominal 512-pixel output frame.
    There are no reflections and no horizon crossings in valid fixtures.
    """
    if rng is None:
        sx, sy, shear, px, py = [
            (1.0, 1.0, 0.0, 0.0, 0.0),
            (1.05, 0.86, 0.14, 0.16, -0.12),
            (0.88, 1.08, -0.12, -0.18, 0.14),
        ][family]
    else:
        sx, sy = rng.uniform(0.85, 1.12, 2)
        shear = rng.uniform(-0.16, 0.16)
        px, py = rng.uniform(-0.20, 0.20, 2)
    normalize = np.array([[1 / 600, 0, -pivot[0] / 600],
                          [0, 1 / 600, -pivot[1] / 600], [0, 0, 1.]])
    perspective = np.array([[1., 0, 0], [0, 1., 0], [px, py, 1.]])
    affine = np.array([[210 * sx, 210 * shear, 0], [0, 210 * sy, 0], [0, 0, 1.]])
    angle = math.radians(float(roll))
    c, s = math.cos(angle), math.sin(angle)
    rotation = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.]])
    translate = np.array([[1., 0, 255.5], [0, 1., 255.5], [0, 0, 1.]])
    return translate @ rotation @ affine @ perspective @ normalize


def observed_fixture(speed, matrix, pivot, anchors, speeds, angles):
    names = list(anchors)
    source_points = np.array([anchors[name] for name in names] +
                             [pivot, source_needle(speed, pivot, speeds, angles)])
    denominator = np.column_stack((source_points, np.ones(len(source_points)))) @ matrix[2]
    assert np.all(denominator > 0), "Valid fixture crossed the horizon"
    assert np.linalg.det(matrix) > 0, "Valid fixture reversed orientation"
    points = project(source_points, matrix)
    return {name: points[i].tolist() for i, name in enumerate(names)}, points[-2].tolist(), points[-1].tolist()


def run_validation():
    import geometry_reader as reader

    started = time.perf_counter()
    pivot, anchors, speeds, angles = source_geometry()
    template = reader.load_template(annotation_path=ANNOTATIONS, calibration_path=CALIBRATION)
    groups, failures = {}, []

    def record_failure(group, detail):
        if len(failures) < 50:
            failures.append({"group": group, **detail})

    def check_exact(group, speed, matrix, subset=None, missing_as_none=False):
        stats = groups.setdefault(group, {"cases": 0, "failures": 0, "maximum_absolute_speed_error_kmh": 0.0})
        stats["cases"] += 1
        ticks, center, tip = observed_fixture(speed, matrix, pivot, anchors, speeds, angles)
        if subset is not None:
            ticks = {name: value if name in subset else None for name, value in ticks.items()} if missing_as_none else {name: ticks[name] for name in subset}
        # Only observations and the fixed template are passed; no oracle matrix.
        try:
            result = reader.read_speed(ticks, center, tip, template=template)
            error = abs(float(result["speed_kmh"]) - float(speed)) if result.get("accepted") else None
            if error is not None:
                stats["maximum_absolute_speed_error_kmh"] = max(stats["maximum_absolute_speed_error_kmh"], error)
            if not result.get("accepted") or error is None or not math.isfinite(error) or error > 1e-6:
                raise AssertionError({"expected_speed_kmh": float(speed), "result": result})
            if subset is not None and len(subset) == 4:
                assert result.get("redundancy_available") is False, "Four-anchor fits must disclose no redundant observations"
            assert result.get("inferred_60_region") == (50.0 + 1e-7 < float(speed) < 70.0 - 1e-7), "Inferred-60 region boundary flag disagrees"
        except Exception as error:
            stats["failures"] += 1
            record_failure(group, {"expected_speed_kmh": float(speed), "error": str(error)})

    rolls = [0, 17.3, 45, 89.999, 90, 120.5, 179.999, 180, 225.2, 270, 315.9, 359.999]
    for index, roll in enumerate(rolls):
        matrix = camera_matrix(roll, pivot, family=index % 3)
        for speed in np.linspace(0, 180, 361):
            check_exact("dense_speed_sweep", speed, matrix)
    for roll in np.linspace(0, 360, 361):
        matrix = camera_matrix(roll, pivot, family=int(roll) % 3)
        for speed in [0, 0.1, 10, 60, 90, 179.9, 180]:
            check_exact("full_circle_roll_sweep", speed, matrix)
    rng = np.random.default_rng(SEED)
    for _ in range(128):
        check_exact("continuous_random_projective_poses", rng.uniform(0, 180),
                    camera_matrix(rng.uniform(0, 360), pivot, rng=rng))
    for count in [4, 5]:
        for subset in combinations(anchors, count):
            for index, roll in enumerate([0, 67.8, 180, 270, 359.99]):
                for speed in [0, 30, 90, 150, 180]:
                    check_exact(f"all_{count}_anchor_subsets", speed,
                                camera_matrix(roll, pivot, family=index % 3), subset,
                                missing_as_none=(index % 2 == 0))
    for roll in [0, 90, 179.999999, 180, 270, 359.999999]:
        for speed in [0, 0.00001, 179.99999, 180]:
            check_exact("endpoint_and_wrap_precision", speed, camera_matrix(roll, pivot, family=2))

    base_matrix = camera_matrix(37.2, pivot, family=1)
    ticks, center, tip = observed_fixture(90, base_matrix, pivot, anchors, speeds, angles)
    names = list(ticks)
    invalid = []

    def invalid_case(name, landmarks=None, center_point=None, tip_point=None):
        invalid.append((name, ticks if landmarks is None else landmarks,
                        center if center_point is None else center_point,
                        tip if tip_point is None else tip_point))

    invalid_case("no_anchors", {})
    invalid.append(("anchor_container_missing", None, center, tip))
    invalid.append(("anchor_container_not_mapping", list(ticks.values()), center, tip))
    invalid_case("unknown_tick_name", {**ticks, "tick_unknown": [10, 20]})
    invalid_case("three_anchors", {name: ticks[name] for name in names[:3]})
    invalid_case("all_anchors_missing", {name: None for name in names})
    invalid_case("coincident_anchors", {name: [100, 100] for name in names})
    invalid_case("collinear_anchors", {name: [100 + i * 10, 120 + i * 5] for i, name in enumerate(names)})
    for name, bad in [("nan_anchor", [float("nan"), 0]), ("infinite_anchor", [0, float("inf")]),
                      ("three_component_anchor", [1, 2, 3]), ("scalar_anchor", 3.0),
                      ("nonnumeric_anchor", ["bad", 1])]:
        invalid_case(name, {**ticks, names[0]: bad})
    invalid_case("nan_pivot", center_point=[float("nan"), 0])
    invalid_case("infinite_tip", tip_point=[0, float("inf")])
    invalid.append(("missing_pivot", ticks, None, tip))
    invalid.append(("missing_tip", ticks, center, None))
    invalid_case("malformed_pivot", center_point=[1, 2, 3])
    invalid_case("zero_length_needle", tip_point=center)
    invalid_case("wrong_pivot", center_point=[center[0] + 60, center[1]])
    invalid_case("reversed_tick_semantics", {name: ticks[other] for name, other in zip(names, reversed(names))})
    swapped = dict(ticks)
    swapped[names[0]], swapped[names[1]] = swapped[names[1]], swapped[names[0]]
    invalid_case("two_swapped_tick_semantics", swapped)
    reflection = np.array([[-1., 0, 511], [0, 1., 0], [0, 0, 1.]])
    invalid_case("mirrored_image_handedness", {name: project([xy], reflection)[0].tolist() for name, xy in ticks.items()},
                 project([center], reflection)[0].tolist(), project([tip], reflection)[0].tolist())
    normalize = np.array([[1 / 600, 0, -pivot[0] / 600], [0, 1 / 600, -pivot[1] / 600], [0, 0, 1.]])
    crossing = np.array([[210., 0, 255.5], [0, 210., 255.5], [0, 0, 1.]]) @ np.array([[1., 0, 0], [0, 1., 0], [3., 0, 1.]]) @ normalize
    invalid_case("projective_horizon_crosses_dial", {name: project([xy], crossing)[0].tolist() for name, xy in anchors.items()},
                 project([pivot], crossing)[0].tolist(), project([source_needle(90, pivot, speeds, angles)], crossing)[0].tolist())
    for label, source_angle in [("one_degree_before_zero", angles[0] - 1), ("one_degree_after_180", angles[-1] + 1)]:
        a = math.radians(float(source_angle))
        outside_tip = pivot + 300 * np.array([math.cos(a), math.sin(a)])
        invalid_case(label, tip_point=project([outside_tip], base_matrix)[0].tolist())
    invalid_failures = 0
    for name, landmarks, center_point, tip_point in invalid:
        try:
            result = reader.read_speed(landmarks, center_point, tip_point, template=template)
            assert result.get("accepted") is False, result
            assert result.get("speed_kmh") is None, "Rejected readings must not expose a speed"
            assert result.get("reason"), "Rejection must explain its reason"
        except Exception as error:
            invalid_failures += 1
            record_failure("invalid_observations", {"case": name, "error": str(error)})

    # This is a measurement-error simulation, not a neural-network benchmark.
    noise_results = []
    for sigma in [0.5, 1.0, 2.0]:
        # Reuse poses, speeds, and Gaussian directions across noise magnitudes.
        noise_rng = np.random.default_rng(SEED + 100)
        accepted_errors, rejected_reasons = [], Counter()
        endpoint_accepted = endpoint_total = 0
        truth = list(noise_rng.uniform(5, 175, 500)) + [0.] * 50 + [180.] * 50
        for speed in truth:
            matrix = camera_matrix(noise_rng.uniform(0, 360), pivot, rng=noise_rng)
            ticks_n, center_n, tip_n = observed_fixture(speed, matrix, pivot, anchors, speeds, angles)
            for name in ticks_n:
                ticks_n[name] = (np.array(ticks_n[name]) + noise_rng.normal(0, sigma, 2)).tolist()
            center_n = (np.array(center_n) + noise_rng.normal(0, sigma, 2)).tolist()
            tip_n = (np.array(tip_n) + noise_rng.normal(0, sigma, 2)).tolist()
            result = reader.read_speed(ticks_n, center_n, tip_n, template=template)
            endpoint = speed in (0, 180)
            endpoint_total += int(endpoint)
            if result.get("accepted"):
                prediction = float(result["speed_kmh"])
                if not math.isfinite(prediction) or not 0 <= prediction <= 180:
                    record_failure("noise_simulation", {"error": "Accepted result outside finite calibrated range"})
                accepted_errors.append(abs(prediction - speed))
                endpoint_accepted += int(endpoint)
            else:
                rejected_reasons[str(result.get("reason"))] += 1
        errors = np.array(accepted_errors, dtype=float)
        noise_results.append({
            "noise_standard_deviation_output_px_per_coordinate": sigma,
            "trials": len(truth), "accepted": len(errors), "rejected": len(truth) - len(errors),
            "accepted_fraction": len(errors) / len(truth),
            "accepted_only_mae_kmh": float(np.mean(errors)) if len(errors) else None,
            "accepted_only_p95_absolute_error_kmh": float(np.percentile(errors, 95)) if len(errors) else None,
            "accepted_only_max_absolute_error_kmh": float(np.max(errors)) if len(errors) else None,
            "endpoint_trials": endpoint_total, "accepted_endpoint_trials": endpoint_accepted,
            "rejection_reasons": dict(rejected_reasons),
        })

    report = {
        "passed": not failures,
        "scope": "Independent forward-projection unit validation of the coordinate-to-speed algorithm. Perfect supplied landmarks; no landmark detector, no training, and no real-image accuracy measurement.",
        "seed": SEED,
        "provenance": {"validator_sha256": file_sha256(__file__), "reader_sha256": file_sha256(ROOT / "geometry_reader.py"),
                       "annotation_sha256": file_sha256(ANNOTATIONS), "calibration_sha256": file_sha256(CALIBRATION)},
        "oracle_homography_given_to_reader": False,
        "calibration": {"named_tick_anchors": list(anchors), "piecewise_speed_knots": speeds.tolist(),
                        "source_angle_degrees_unwrapped": angles.tolist(), "speed_error_tolerance_kmh": 1e-6},
        "exact_geometry_checks": groups,
        "exact_cases": sum(group["cases"] for group in groups.values()),
        "invalid_observations": {"cases": len(invalid), "failures": invalid_failures, "case_names": [r[0] for r in invalid]},
        "noise_simulation": {
            "scope": "Independent zero-mean Gaussian perturbations of every tick, pivot, and tip x/y coordinate in a nominal 512-pixel image. This is simulated label/detection error, not model accuracy or calibrated confidence.",
            "speed_distribution_per_level": "500 uniform draws from 5–175 km/h, plus 50 at 0 and 50 at 180 km/h",
            "error_statistics_denominator": "Accepted readings only; rejection counts and endpoint acceptance are reported separately.",
            "paired_noise_levels": True,
            "results": noise_results,
        },
        "limitations": [
            "Correct semantic tick identities are supplied; this does not establish that a neural network can locate or identify them.",
            "Expected speeds use the same fixed manual calibration as the reader. Annotation errors, including the inferred 60 tick, are not validated against the motorcycle.",
            "Exact projective fixtures are planar and physically oriented. Real lens distortion, nonplanarity, glare, blur, occlusion, and out-of-distribution dials remain untested.",
            "With four anchors, an exact projective fit has no redundant observations to detect arbitrary landmark mistakes.",
            "The reader's geometric rejection thresholds are engineering checks, not a calibrated probability of correctness.",
            "No 98% model or real-world accuracy claim follows from these tests.",
        ],
        "failures": failures,
        "elapsed_seconds": time.perf_counter() - started,
    }
    plot_noise_sensitivity(noise_results)
    report["noise_simulation"]["plot"] = "geometry_noise_sensitivity.png"
    REPORT.write_text(json.dumps(report, indent=2, allow_nan=False), encoding="utf-8")
    return report


def plot_noise_sensitivity(rows):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    sigma = [r["noise_standard_deviation_output_px_per_coordinate"] for r in rows]
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
    for field, label, color in [("accepted_only_mae_kmh", "Mean error", "#007f82"),
                                ("accepted_only_p95_absolute_error_kmh", "95th percentile error", "#b65a21")]:
        values = [r[field] for r in rows]
        axes[0].plot(sigma, values, "o-", label=label, color=color)
        for x, y in zip(sigma, values):
            if y is not None:
                axes[0].annotate(f"{y:.2f}", (x, y), xytext=(0, 7), textcoords="offset points", ha="center", fontsize=9)
    axes[0].set(ylabel="Speed error among accepted readings (km/h)", ylim=(0, None))
    axes[0].legend(frameon=False, fontsize=9)
    acceptance = [r["accepted_fraction"] * 100 for r in rows]
    axes[1].bar(sigma, acceptance, width=0.25, color="#497397")
    for x, y, row in zip(sigma, acceptance, rows):
        axes[1].text(x, y + 2, f"{row['accepted']}/{row['trials']}\n{y:.1f}%", ha="center", fontsize=9)
    axes[1].set(ylabel="Readings accepted (%)", ylim=(0, 115))
    for axis in axes:
        axis.set(xlabel="Landmark noise standard deviation (output pixels)", xticks=sigma)
        axis.grid(axis="y", alpha=0.2)
        axis.set_axisbelow(True)
    fig.suptitle("Simulated landmark error — not model accuracy", fontsize=14)
    fig.text(0.5, 0.01, "600 paired trials per level; includes 100 endpoint readings. Rejected readings are excluded from error statistics.", ha="center", fontsize=8)
    fig.tight_layout(rect=(0, 0.04, 1, 0.94))
    fig.savefig(ROOT / "geometry_noise_sensitivity.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    report = run_validation()
    print(json.dumps({"passed": report["passed"], "exact_cases": report["exact_cases"],
                      "invalid_cases": report["invalid_observations"]["cases"],
                      "failures": report["failures"], "noise_simulation": report["noise_simulation"]["results"],
                      "report": str(REPORT), "elapsed_seconds": report["elapsed_seconds"]}, indent=2))
    raise SystemExit(0 if report["passed"] else 1)
