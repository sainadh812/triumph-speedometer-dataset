ARC + NEEDLE: STEPS 2 AND 3 REVIEW PACK

20 single-channel grayscale PNGs, each 512 x 512 pixels.
Status: visual review batch. No model has been trained on this batch.

START HERE
contact_sheet_inputs.png   All 20 actual model inputs.
contact_sheet_labels.png   The same images with separate label overlays.
same_speed_three_views.png Same synthetic 60 km/h pose in three camera views.
images/                   Individual grayscale inputs, with no label graphics.
overlays/                 Color overlays for human inspection only.
labels.json               Complete labels, transforms, provenance and masks.
labels.csv                Compact speed, needle position and camera summary.
masks/                    Binary 0/255 masks, each 512 x 512.

OVERLAY COLORS
Cyan: scale arc. Yellow: visible named tick landmarks.
Pink: needle pivot, tip and direction.
Orange: uncertain/occluded arc or a covered named tick.
Overlay graphics must never be used as training inputs.

STEP 2: THE CALCULATION
Six named landmarks identify the 0, 40, 80, 120, 160 and 180 km/h ticks.
At least four well-spaced visible ticks are needed to estimate a homography
(a perspective correction) mapping an image back to the source template.
The same estimated correction is applied to the needle pivot and tip.
Its corrected angle is then converted to speed using the 19 calibrated
ticks at 10 km/h intervals, with interpolation between adjacent ticks.

The calculator receives the named tick coordinates and needle endpoints.
It does not receive the known camera transform stored in the labels.
The arc mask will provide a future model with supervision for the scale's
shape; an arc alone does not identify the dial's rotation or speed scale.
Invalid, insufficient or out-of-range geometry is rejected, not clamped.

Independent validation passed 7,536 exact geometry cases and 26 invalid
input/rejection cases, including full-circle rotation and perspective.
All 20 generated samples also recover their intended speeds with exact
coordinates. This checks mathematical consistency, not model accuracy.
The separate noise simulation perturbs coordinates; it does not measure
how a trained model will perform on image noise or on a real dashboard.

STEP 3: HOW THE IMAGES WERE MADE
The previously approved grayscale master, cleaned dial plate and needle
layer were reused without alteration. The needle is positioned at the
calibrated speed, then the complete image and every geometric label receive
the same camera transform. Lighting, shadow, reflection, blur, sensor noise
and JPEG effects are added to selected samples. Fixed seeds are recorded.
No new AI image generation was used for these 20 images.

Speeds span 0 to 180 km/h, including intermediate values. Camera rolls
include upright, +/-90 degrees, upside down and arbitrary angles. Positive
camera rotation is clockwise in the displayed image. Constant gray wedges
outside rotated images are synthetic border fill, not real scenery.

LABEL CONVENTIONS
Coordinates: x increases right, y increases down; pixel centers 0 to 511.
Normalized coordinates divide x and y by 511, so endpoints lie in [0,1].
speed_kmh: intended synthetic speed, not an independent physical reading.
needle_position_px: pivot, visible shaft tip, and scale intersection anchor.
tick_landmarks: named point, speed, position, visibility, loss validity.
arc_centerline_px: transformed polyline through the scale ribbon.
source_to_output_homography_3x3: provenance/augmentation transform only.

MASKS
arc_amodal: complete fitted scale ribbon, including inferred hidden areas.
arc_visible: ribbon with uncertain and needle-occluded regions removed.
arc_loss_valid: image footprint excluding uncertain/occluded regions;
  multiply the arc_visible segmentation loss by this mask.
arc_ignore: uncertainty around the original 60 km/h region plus the current
  needle's intersection with the arc (with a one-pixel safety margin).
source60_uncertainty: uncertainty fixed to the source, transformed with it.
arc_occluded_by_needle: current needle intersection with the fitted ribbon.
needle_shaft: rendered shaft support before blur; stationary hub excluded.
image_footprint: source image coverage, excluding synthetic border fill.
Covered tick landmarks have heatmap_loss_valid=false. Mask boundaries
describe geometry before blur/lighting, not thresholded final brightness.

REVIEW LIMITS
The master is an AI reconstruction. Its calibration is not yet verified
against a physical dashboard. The obscured 60 km/h tick was inferred from
neighboring ticks. Samples influenced by that calibration are flagged
inferred_60_influence=true and marked with an asterisk on the contact sheet.

All 20 samples are review_only. Variants at the same speed share a
source_pose_group; all images also share a single dashboard master.
These are not independent real-world training/test datasets. The batch
cannot establish 98% accuracy or prove unseen-camera performance.

PROVENANCE
labels.json records source hashes, seeds, transforms and image/mask hashes.
Paths in source_artifact_hashes are relative to the original speedometer_colab
project. source_annotations_snapshot.json is an unchanged archival copy;
its image/mask references retain the original ring_annotation_review base.
calibration_snapshot.json contains the existing 19-tick source calibration.

The ZIP's code folder contains the geometry reader and generation/validation
scripts for reference. The generator and full validators use the original
project assets. To use the reader independently after unzipping, supply
explicit paths to these two snapshots when calling load_template():

  template = load_template(
      'review20/source_annotations_snapshot.json',
      'review20/calibration_snapshot.json')
  result = read_speed(visible_named_tick_coordinates, pivot, tip, template)

NEXT REVIEW
Inspect whether the needle points to the stated speed and whether the cyan
arc follows the printed scale. Inspect the intermediate speeds, upside-down
views and blurred images. After this review, model changes and larger-scale
training can be planned using these label types.
